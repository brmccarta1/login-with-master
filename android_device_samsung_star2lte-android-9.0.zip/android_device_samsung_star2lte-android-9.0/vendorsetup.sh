add_lunch_combo omni_star2lte-eng

